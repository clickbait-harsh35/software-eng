<?php
// Run once after importing database/schema.sql, then delete this file for safer local use.
require_once __DIR__ . '/config/db.php';
$pdo->beginTransaction();
try {
    $users = [
        ['admin', 'Admin@123', 'ADMIN'],
        ['teacher1', 'Teacher@123', 'TEACHER'],
        ['student1', 'Student@123', 'STUDENT'],
        ['student2', 'Student@123', 'STUDENT'],
    ];
    $insertUser = $pdo->prepare('INSERT IGNORE INTO users (username,password_hash,role) VALUES (?,?,?)');
    foreach ($users as $u) $insertUser->execute([$u[0], password_hash($u[1], PASSWORD_DEFAULT), $u[2]]);

    $pdo->exec("INSERT IGNORE INTO classes (class_id,class_name,section,academic_year) VALUES (1,'BSc Computer Science','A','2026-27')");
    $pdo->exec("INSERT IGNORE INTO subjects (subject_id,subject_code,subject_name) VALUES (1,'CS101','Introduction to Computer Science'),(2,'MA101','Mathematics')");

    $adminId = (int)$pdo->query("SELECT user_id FROM users WHERE username='admin'")->fetchColumn();
    $teacherUserId = (int)$pdo->query("SELECT user_id FROM users WHERE username='teacher1'")->fetchColumn();
    $student1UserId = (int)$pdo->query("SELECT user_id FROM users WHERE username='student1'")->fetchColumn();
    $student2UserId = (int)$pdo->query("SELECT user_id FROM users WHERE username='student2'")->fetchColumn();

    $q = $pdo->prepare('INSERT IGNORE INTO teachers (user_id,employee_code,full_name) VALUES (?,?,?)');
    $q->execute([$teacherUserId,'T001','Demo Teacher']);
    $teacherId = (int)$pdo->query("SELECT teacher_id FROM teachers WHERE user_id=$teacherUserId")->fetchColumn();

    $q = $pdo->prepare('INSERT IGNORE INTO students (user_id,roll_no,full_name,class_id) VALUES (?,?,?,1)');
    $q->execute([$student1UserId,'STU001','Aarav Sharma']);
    $q->execute([$student2UserId,'STU002','Diya Verma']);
    $s1 = (int)$pdo->query("SELECT student_id FROM students WHERE user_id=$student1UserId")->fetchColumn();
    $s2 = (int)$pdo->query("SELECT student_id FROM students WHERE user_id=$student2UserId")->fetchColumn();

    $pdo->exec("INSERT IGNORE INTO teacher_subjects (teacher_id,class_id,subject_id) VALUES ($teacherId,1,1),($teacherId,1,2)");
    $q = $pdo->prepare('INSERT IGNORE INTO enrollments (student_id,subject_id,academic_year) VALUES (?,?,?)');
    foreach ([$s1,$s2] as $sid) foreach ([1,2] as $sub) $q->execute([$sid,$sub,'2026-27']);

    // Add one sample completed session only if no session exists for this subject/date.
    $count = (int)$pdo->query("SELECT COUNT(*) FROM sessions WHERE class_id=1 AND subject_id=1 AND session_date='2026-11-09'")->fetchColumn();
    if (!$count) {
        $q = $pdo->prepare("INSERT INTO sessions (class_id,subject_id,teacher_id,session_date,starts_at,ends_at,status) VALUES (1,1,?,'2026-11-09','2026-11-09 10:00:00','2026-11-09 11:00:00','CLOSED')");
        $q->execute([$teacherId]); $sessionId = (int)$pdo->lastInsertId();
        $q = $pdo->prepare('INSERT INTO attendance (session_id,student_id,status,marked_by) VALUES (?,?,?,?)');
        $q->execute([$sessionId,$s1,'PRESENT',$teacherUserId]);
        $q->execute([$sessionId,$s2,'ABSENT',$teacherUserId]);
    }
    $pdo->commit();
    echo '<h2>Setup complete</h2><p>Demo users created. <a href="public/index.php">Open the application</a>.</p>';
} catch (Throwable $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo 'Setup failed: ' . htmlspecialchars($e->getMessage());
}
