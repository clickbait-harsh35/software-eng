<?php
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function csrf_token() { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf() { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Invalid request token. Refresh and try again.'); } }
function require_role($roles) { if (empty($_SESSION['user_id'])) { header('Location: index.php'); exit; } if (!in_array($_SESSION['role'], (array)$roles, true)) { http_response_code(403); exit('Access denied.'); } }
function page_header($title) { echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($title).'</title><link rel="stylesheet" href="../assets/style.css"></head><body><header><div><strong>Student Attendance</strong><span>Management System</span></div>'; if (!empty($_SESSION['user_id'])) echo '<nav><a href="index.php">Dashboard</a><a href="?action=logout">Logout</a></nav>'; echo '</header><main>'; }
function page_footer() { echo '</main><footer>Academic prototype · Use fictional test data</footer></body></html>'; }

$action = $_GET['action'] ?? '';
if ($action === 'logout') { $_SESSION = []; session_destroy(); header('Location: index.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'login') {
    verify_csrf();
    $stmt = $pdo->prepare('SELECT user_id,username,password_hash,role,is_active FROM users WHERE username=? LIMIT 1');
    $stmt->execute([trim($_POST['username'] ?? '')]); $u = $stmt->fetch();
    if ($u && (int)$u['is_active'] === 1 && password_verify($_POST['password'] ?? '', $u['password_hash'])) {
        session_regenerate_id(true); $_SESSION['user_id']=(int)$u['user_id']; $_SESSION['username']=$u['username']; $_SESSION['role']=$u['role']; header('Location: index.php'); exit;
    }
    $error = 'Invalid username or password.';
}

if (empty($_SESSION['user_id'])) {
    page_header('Login');
    echo '<section class="login card"><h1>Sign in</h1><p class="muted">Access your attendance dashboard.</p>';
    if ($error) echo '<div class="alert error">'.h($error).'</div>';
    echo '<form method="post"><input type="hidden" name="form" value="login"><input type="hidden" name="csrf" value="'.h(csrf_token()).'"><label>Username</label><input name="username" required autofocus><label>Password</label><input type="password" name="password" required><button>Login</button></form><p class="muted small">Demo accounts are listed in README.md.</p></section>';
    page_footer(); exit;
}

$role = $_SESSION['role'];
if ($role === 'ADMIN') {
    require_role('ADMIN'); page_header('Administrator Dashboard');
    $counts = [];
    foreach (['Students'=>'students','Teachers'=>'teachers','Classes'=>'classes','Subjects'=>'subjects','Sessions'=>'sessions'] as $label=>$table) $counts[$label]=(int)$pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
    echo '<h1>Administrator Dashboard</h1><p class="muted">Welcome, '.h($_SESSION['username']).'. Overview of the sample database.</p><div class="stats">';
    foreach ($counts as $label=>$n) echo '<div class="stat card"><span>'.h($label).'</span><strong>'.$n.'</strong></div>';
    echo '</div><section class="card"><h2>System overview</h2><p>This starter version includes role-based login, demo academic data, teacher attendance entry and student attendance summaries. Full user-management screens and QR attendance are not included in this first runnable build.</p></section>';
    page_footer(); exit;
}

if ($action === 'students') {
    require_role('TEACHER');
    $classId=(int)($_GET['class_id']??0); $subjectId=(int)($_GET['subject_id']??0);
    $q=$pdo->prepare('SELECT t.teacher_id FROM teachers t WHERE t.user_id=?'); $q->execute([$_SESSION['user_id']]); $tid=(int)$q->fetchColumn();
    $q=$pdo->prepare('SELECT allocation_id FROM teacher_subjects WHERE teacher_id=? AND class_id=? AND subject_id=?'); $q->execute([$tid,$classId,$subjectId]); if (!$q->fetch()) { http_response_code(403); exit('Access denied.'); }
    $q=$pdo->prepare('SELECT s.student_id,s.roll_no,s.full_name FROM students s JOIN enrollments e ON e.student_id=s.student_id WHERE s.class_id=? AND e.subject_id=? ORDER BY s.roll_no'); $q->execute([$classId,$subjectId]); $students=$q->fetchAll();
    if (!$students) { echo '<p>No enrolled students found.</p>'; exit; }
    echo '<h3>Mark each student</h3><div class="table-wrap"><table><thead><tr><th>Roll No.</th><th>Student</th><th>Status</th></tr></thead><tbody>';
    foreach ($students as $s) echo '<tr><td>'.h($s['roll_no']).'</td><td>'.h($s['full_name']).'</td><td><select name="status['.(int)$s['student_id'].']" form="attendanceForm" required><option value="">Choose</option><option value="PRESENT">Present</option><option value="ABSENT">Absent</option></select></td></tr>';
    echo '</tbody></table></div><button type="submit" form="attendanceForm">Save attendance</button>'; exit;
}

if ($role === 'TEACHER') {
    require_role('TEACHER');
    $teacherStmt=$pdo->prepare('SELECT teacher_id,full_name FROM teachers WHERE user_id=?'); $teacherStmt->execute([$_SESSION['user_id']]); $teacher=$teacherStmt->fetch();
    if (!$teacher) exit('Teacher profile is missing. Run setup.php again.');
    $notice='';
    if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['form']??'')==='attendance') {
        verify_csrf();
        $classId=(int)($_POST['class_id']??0); $subjectId=(int)($_POST['subject_id']??0); $date=$_POST['session_date']??'';
        $allocation=$pdo->prepare('SELECT allocation_id FROM teacher_subjects WHERE teacher_id=? AND class_id=? AND subject_id=?');
        $allocation->execute([$teacher['teacher_id'],$classId,$subjectId]);
        if (!$allocation->fetch() || !preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)) $notice='Invalid class, subject or date.';
        else {
            $students=$pdo->prepare('SELECT s.student_id FROM students s JOIN enrollments e ON e.student_id=s.student_id WHERE s.class_id=? AND e.subject_id=?'); $students->execute([$classId,$subjectId]); $studentIds=array_map('intval',$students->fetchAll(PDO::FETCH_COLUMN));
            if (!$studentIds) $notice='No enrolled students found for this class and subject.';
            else {
                try {
                    $pdo->beginTransaction();
                    $q=$pdo->prepare("INSERT INTO sessions (class_id,subject_id,teacher_id,session_date,starts_at,ends_at,status) VALUES (?,?,?,?,?,?,'CLOSED')");
                    $q->execute([$classId,$subjectId,$teacher['teacher_id'],$date,$date.' 00:00:00',$date.' 23:59:59']); $sid=(int)$pdo->lastInsertId();
                    $ins=$pdo->prepare('INSERT INTO attendance (session_id,student_id,status,marked_by) VALUES (?,?,?,?)');
                    foreach ($studentIds as $studentId) { $status=$_POST['status'][$studentId]??''; if (!in_array($status,['PRESENT','ABSENT'],true)) throw new RuntimeException('Choose a status for every student.'); $ins->execute([$sid,$studentId,$status,$_SESSION['user_id']]); }
                    $pdo->commit(); $notice='Attendance saved successfully.';
                } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); $notice='Could not save attendance. Check that every student has a status and that this date has not already been recorded.'; }
            }
        }
    }
    $alloc=$pdo->prepare('SELECT ts.class_id,c.class_name,c.section,ts.subject_id,s.subject_name FROM teacher_subjects ts JOIN classes c ON c.class_id=ts.class_id JOIN subjects s ON s.subject_id=ts.subject_id WHERE ts.teacher_id=? ORDER BY c.class_name,s.subject_name'); $alloc->execute([$teacher['teacher_id']]); $allocations=$alloc->fetchAll();
    page_header('Teacher Dashboard'); echo '<h1>Teacher Dashboard</h1><p class="muted">Welcome, '.h($teacher['full_name']).'. Record attendance for your allocated subjects.</p>';
    if ($notice) echo '<div class="alert">'.h($notice).'</div>';
    echo '<section class="card"><h2>Mark attendance</h2><form method="post" id="attendanceForm"><input type="hidden" name="form" value="attendance"><input type="hidden" name="csrf" value="'.h(csrf_token()).'"><div class="form-grid"><div><label>Class / Subject</label><select name="allocation" id="allocation" required><option value="">Select allocation</option>';
    foreach ($allocations as $a) echo '<option value="'.(int)$a['class_id'].'|'.(int)$a['subject_id'].'">'.h($a['class_name'].' '.$a['section'].' — '.$a['subject_name']).'</option>';
    echo '</select><input type="hidden" name="class_id" id="class_id"><input type="hidden" name="subject_id" id="subject_id"></div><div><label>Session date</label><input type="date" name="session_date" value="'.date('Y-m-d').'" required></div></div><button type="button" id="loadStudents">Load student list</button><div id="studentList" class="student-list"></div></form></section>';
    echo '<script>document.getElementById("loadStudents").addEventListener("click",async()=>{const v=document.getElementById("allocation").value;if(!v){alert("Select a class and subject first.");return;}const [c,s]=v.split("|");document.getElementById("class_id").value=c;document.getElementById("subject_id").value=s;const box=document.getElementById("studentList");box.innerHTML="Loading...";const url="?action=students&class_id="+encodeURIComponent(c)+"&subject_id="+encodeURIComponent(s);const res=await fetch(url);box.innerHTML=await res.text();});</script>';
    page_footer(); exit;
}

if ($role === 'STUDENT') {
    require_role('STUDENT');
    $q=$pdo->prepare('SELECT student_id,roll_no,full_name,class_id FROM students WHERE user_id=?'); $q->execute([$_SESSION['user_id']]); $student=$q->fetch();
    if (!$student) exit('Student profile is missing. Run setup.php again.');
    $q=$pdo->prepare("SELECT sub.subject_name,COUNT(DISTINCT ses.session_id) AS held,SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END) AS attended,CASE WHEN COUNT(DISTINCT ses.session_id)=0 THEN NULL ELSE ROUND(100.0*SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END)/COUNT(DISTINCT ses.session_id),2) END AS pct FROM enrollments e JOIN subjects sub ON sub.subject_id=e.subject_id LEFT JOIN sessions ses ON ses.subject_id=sub.subject_id AND ses.class_id=? AND ses.status IN ('CLOSED','EXPIRED') LEFT JOIN attendance a ON a.session_id=ses.session_id AND a.student_id=e.student_id WHERE e.student_id=? GROUP BY sub.subject_id,sub.subject_name ORDER BY sub.subject_name"); $q->execute([$student['class_id'],$student['student_id']]); $rows=$q->fetchAll();
    page_header('Student Dashboard'); echo '<h1>Student Dashboard</h1><p class="muted">'.h($student['full_name']).' · Roll No: '.h($student['roll_no']).'</p><section class="card"><h2>Subject-wise attendance</h2><div class="table-wrap"><table><thead><tr><th>Subject</th><th>Classes held</th><th>Attended</th><th>Attendance %</th><th>Status</th></tr></thead><tbody>';
    foreach ($rows as $r) { $pct=$r['pct']; $status=$pct===null?'No sessions yet':((float)$pct<75?'Below 75%':'At / above 75%'); echo '<tr><td>'.h($r['subject_name']).'</td><td>'.(int)$r['held'].'</td><td>'.(int)$r['attended'].'</td><td>'.($pct===null?'—':number_format((float)$pct,2).'%').'</td><td>'.h($status).'</td></tr>'; }
    echo '</tbody></table></div><p class="muted small">Attendance = sessions attended ÷ sessions held × 100. The default shortage threshold is 75%.</p></section>';
    page_footer(); exit;
}

http_response_code(403); echo 'Unknown role or action.';
