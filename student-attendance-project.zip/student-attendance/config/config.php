<?php
// Local XAMPP development settings. Change these for your environment.
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'attendance_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('APP_NAME', 'Student Attendance Management System');
date_default_timezone_set('Asia/Kolkata');
