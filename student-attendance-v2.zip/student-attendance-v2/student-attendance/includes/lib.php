<?php
// Shared helpers used by every page. Include with: require_once __DIR__ . '/../includes/lib.php';
require_once __DIR__ . '/../config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

const STATUSES = ['PRESENT', 'ABSENT', 'LEAVE'];
const SESSION_IDLE_SECONDS = 1800; // auto logout after 30 minutes of no activity

function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function csrf_token() { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field() { return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">'; }
function verify_csrf() {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Invalid request token. Refresh and try again.'); }
}

// ---- session timeout (SRS: session timeout) ----
if (!empty($_SESSION['user_id'])) {
    if (time() - ($_SESSION['last_seen'] ?? time()) > SESSION_IDLE_SECONDS) {
        $_SESSION = []; session_destroy(); session_start(); $_SESSION['flash'] = ['error', 'You were logged out after 30 minutes of inactivity.'];
    } else { $_SESSION['last_seen'] = time(); }
}

function flash($type, $msg) { $_SESSION['flash'] = [$type, $msg]; }
function redirect($url) { header('Location: ' . $url); exit; }

function require_role($roles) {
    if (empty($_SESSION['user_id'])) redirect('index.php');
    if (!in_array($_SESSION['role'], (array)$roles, true)) { http_response_code(403); exit('Access denied.'); }
}

// ---- settings (threshold etc.) ----
function setting($pdo, $key, $default = null) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try { foreach ($pdo->query('SELECT setting_key, setting_value FROM settings') as $r) $cache[$r['setting_key']] = $r['setting_value']; } catch (Throwable $e) {}
    }
    return $cache[$key] ?? $default;
}
function threshold($pdo) { return (float)setting($pdo, 'threshold', 75); }

// ---- audit log (SRS FR24) ----
function audit($pdo, $action, $entity, $entityId, $reason = '') {
    $q = $pdo->prepare('INSERT INTO audit_logs (actor_user_id, action, entity_name, entity_id, reason) VALUES (?,?,?,?,?)');
    $q->execute([$_SESSION['user_id'], $action, $entity, (string)$entityId, $reason]);
}

// ---- layout ----
function nav_links() {
    $role = $_SESSION['role'] ?? '';
    $links = [];
    if ($role === 'ADMIN') $links = ['admin.php' => 'Dashboard', 'admin.php?tab=users' => 'Users', 'admin.php?tab=academic' => 'Academic', 'admin.php?tab=leaves' => 'Leaves', 'admin.php?tab=sessions' => 'Edit attendance', 'reports.php' => 'Reports', 'admin.php?tab=settings' => 'Settings', 'admin.php?tab=audit' => 'Audit log'];
    if ($role === 'TEACHER') $links = ['teacher.php' => 'Mark attendance', 'teacher.php?tab=edit' => 'Edit records', 'teacher.php?tab=requests' => 'Requests', 'reports.php' => 'Reports'];
    if ($role === 'STUDENT') $links = ['student.php' => 'Dashboard', 'student.php?tab=daily' => 'Day by day', 'student.php?tab=leave' => 'Leave', 'student.php?tab=corrections' => 'Corrections', 'student.php?tab=profile' => 'Profile'];
    return $links;
}
function page_header($title) {
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . h($title) . '</title><link rel="stylesheet" href="../assets/style.css"></head><body><header><div><strong>Student Attendance</strong><span>Management System</span></div>';
    if (!empty($_SESSION['user_id'])) {
        echo '<nav>';
        foreach (nav_links() as $url => $label) echo '<a href="' . h($url) . '">' . h($label) . '</a>';
        echo '<a href="index.php?action=logout">Logout (' . h($_SESSION['username']) . ')</a></nav>';
    }
    echo '</header><main>';
    if (!empty($_SESSION['flash'])) {
        [$type, $msg] = $_SESSION['flash']; unset($_SESSION['flash']);
        echo '<div class="alert ' . ($type === 'error' ? 'error' : ($type === 'ok' ? 'ok' : '')) . '">' . h($msg) . '</div>';
    }
}
function page_footer() { echo '</main><footer>Academic prototype · Use fictional test data</footer></body></html>'; }

function status_badge($status) {
    $cls = ['PRESENT' => 'ok', 'ABSENT' => 'bad', 'LEAVE' => 'warn', 'PENDING' => 'warn', 'APPROVED' => 'ok', 'REJECTED' => 'bad', 'CANCELLED' => 'muted'][$status] ?? '';
    return '<span class="badge ' . $cls . '">' . h(ucfirst(strtolower($status))) . '</span>';
}
function status_select($name, $selected = 'PRESENT', $form = '') {
    $o = '<select name="' . h($name) . '"' . ($form ? ' form="' . h($form) . '"' : '') . '>';
    foreach (STATUSES as $s) $o .= '<option value="' . $s . '"' . ($s === $selected ? ' selected' : '') . '>' . ucfirst(strtolower($s)) . '</option>';
    return $o . '</select>';
}
function valid_date($d) { $dt = DateTime::createFromFormat('Y-m-d', (string)$d); return $dt && $dt->format('Y-m-d') === $d; }

// ---- lookups ----
function current_teacher($pdo) {
    $q = $pdo->prepare('SELECT teacher_id, full_name FROM teachers WHERE user_id=?'); $q->execute([$_SESSION['user_id']]); return $q->fetch() ?: null;
}
function current_student($pdo) {
    $q = $pdo->prepare('SELECT student_id, roll_no, full_name, class_id, email, phone FROM students WHERE user_id=?'); $q->execute([$_SESSION['user_id']]); return $q->fetch() ?: null;
}
function teacher_allocations($pdo, $teacherId) {
    $q = $pdo->prepare('SELECT ts.class_id,c.class_name,c.section,ts.subject_id,s.subject_name FROM teacher_subjects ts JOIN classes c ON c.class_id=ts.class_id JOIN subjects s ON s.subject_id=ts.subject_id WHERE ts.teacher_id=? ORDER BY c.class_name,s.subject_name');
    $q->execute([$teacherId]); return $q->fetchAll();
}
function teacher_owns($pdo, $teacherId, $classId, $subjectId) {
    $q = $pdo->prepare('SELECT 1 FROM teacher_subjects WHERE teacher_id=? AND class_id=? AND subject_id=?'); $q->execute([$teacherId, $classId, $subjectId]); return (bool)$q->fetch();
}
function all_classes($pdo) { return $pdo->query('SELECT class_id,class_name,section,academic_year FROM classes ORDER BY class_name,section')->fetchAll(); }
function all_subjects($pdo) { return $pdo->query('SELECT subject_id,subject_code,subject_name FROM subjects ORDER BY subject_name')->fetchAll(); }
function class_label($c) { return $c['class_name'] . ($c['section'] ? ' ' . $c['section'] : ''); }

// Does this student have approved leave covering this date?
function on_approved_leave($pdo, $studentId, $date) {
    $q = $pdo->prepare("SELECT 1 FROM leave_requests WHERE student_id=? AND status='APPROVED' AND ? BETWEEN from_date AND to_date LIMIT 1");
    $q->execute([$studentId, $date]); return (bool)$q->fetch();
}

// ---- percentage maths ----
// attended = PRESENT (+ LEAVE when the setting leave_counts_as_present is 1). held = sessions with a record for that student.
function pct_expr($pdo) {
    $leave = setting($pdo, 'leave_counts_as_present', '1') === '1' ? "+SUM(CASE WHEN a.status='LEAVE' THEN 1 ELSE 0 END)" : '';
    return "SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END)$leave";
}
function student_summary($pdo, $studentId) {
    $att = pct_expr($pdo);
    $q = $pdo->prepare("SELECT sub.subject_id, sub.subject_name, COUNT(a.attendance_id) AS held,
        SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END) AS present_n,
        SUM(CASE WHEN a.status='ABSENT' THEN 1 ELSE 0 END) AS absent_n,
        SUM(CASE WHEN a.status='LEAVE' THEN 1 ELSE 0 END) AS leave_n,
        $att AS attended
        FROM enrollments e JOIN subjects sub ON sub.subject_id=e.subject_id
        LEFT JOIN attendance a ON a.student_id=e.student_id AND a.session_id IN (SELECT session_id FROM sessions WHERE subject_id=sub.subject_id AND status='CLOSED')
        WHERE e.student_id=? GROUP BY sub.subject_id, sub.subject_name ORDER BY sub.subject_name");
    $q->execute([$studentId]); $rows = $q->fetchAll();
    foreach ($rows as &$r) { $r['pct'] = (int)$r['held'] === 0 ? null : round(100 * (float)$r['attended'] / (int)$r['held'], 2); }
    return $rows;
}
function class_report($pdo, $classId, $subjectId, $from, $to) {
    $att = pct_expr($pdo);
    $q = $pdo->prepare("SELECT s.student_id, s.roll_no, s.full_name, COUNT(a.attendance_id) AS held,
        SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END) AS present_n,
        SUM(CASE WHEN a.status='ABSENT' THEN 1 ELSE 0 END) AS absent_n,
        SUM(CASE WHEN a.status='LEAVE' THEN 1 ELSE 0 END) AS leave_n,
        $att AS attended
        FROM students s JOIN enrollments e ON e.student_id=s.student_id AND e.subject_id=?
        LEFT JOIN attendance a ON a.student_id=s.student_id AND a.session_id IN (SELECT session_id FROM sessions WHERE class_id=? AND subject_id=? AND status='CLOSED' AND session_date BETWEEN ? AND ?)
        WHERE s.class_id=? GROUP BY s.student_id, s.roll_no, s.full_name ORDER BY s.roll_no");
    $q->execute([$subjectId, $classId, $subjectId, $from, $to, $classId]); $rows = $q->fetchAll();
    foreach ($rows as &$r) { $r['pct'] = (int)$r['held'] === 0 ? null : round(100 * (float)$r['attended'] / (int)$r['held'], 2); }
    return $rows;
}

// ---- writing attendance (used by marking, editing and leave approval) ----
function set_attendance($pdo, $sessionId, $studentId, $status, $reason, $action = 'ATTENDANCE_EDIT') {
    $q = $pdo->prepare('SELECT attendance_id,status FROM attendance WHERE session_id=? AND student_id=?'); $q->execute([$sessionId, $studentId]); $old = $q->fetch();
    if (!$old) return false;
    if ($old['status'] === $status) return false;
    $pdo->prepare('UPDATE attendance SET status=?, marked_by=? WHERE attendance_id=?')->execute([$status, $_SESSION['user_id'], $old['attendance_id']]);
    audit($pdo, $action, 'attendance', $old['attendance_id'], $old['status'] . ' -> ' . $status . ($reason !== '' ? ' | ' . $reason : ''));
    return true;
}
// When a leave is approved, flip any ABSENT records already saved inside the range to LEAVE.
function apply_leave_to_existing($pdo, $leave) {
    $q = $pdo->prepare("SELECT a.session_id FROM attendance a JOIN sessions s ON s.session_id=a.session_id WHERE a.student_id=? AND a.status='ABSENT' AND s.session_date BETWEEN ? AND ?");
    $q->execute([$leave['student_id'], $leave['from_date'], $leave['to_date']]); $n = 0;
    foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $sid) if (set_attendance($pdo, $sid, $leave['student_id'], 'LEAVE', 'Leave #' . $leave['leave_id'] . ' approved', 'LEAVE_APPLIED')) $n++;
    return $n;
}
function csv_download($filename, $header, $rows) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w'); fwrite($out, "\xEF\xBB\xBF"); // BOM so Excel reads UTF-8
    fputcsv($out, $header); foreach ($rows as $r) fputcsv($out, $r); fclose($out); exit;
}
