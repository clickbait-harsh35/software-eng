<?php
require_once __DIR__ . '/../includes/lib.php';
require_role('ADMIN');
$tab = $_GET['tab'] ?? 'home';

function try_delete($pdo, $sql, $id, $what) {
    try { $pdo->prepare($sql)->execute([$id]); audit($pdo, 'DELETE', $what, $id); flash('ok', ucfirst($what) . ' deleted.'); }
    catch (PDOException $e) { flash('error', "That $what is still in use (students, allocations or attendance refer to it), so it cannot be deleted."); }
}

// ---------- POST handlers ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $form = $_POST['form'] ?? ''; $back = 'admin.php?tab=' . urlencode($_POST['back'] ?? 'home');

    if ($form === 'create_user') {
        $role = $_POST['role'] ?? ''; $user = trim($_POST['username'] ?? ''); $pass = $_POST['password'] ?? ''; $name = trim($_POST['full_name'] ?? ''); $code = trim($_POST['code'] ?? ''); $classId = (int)($_POST['class_id'] ?? 0);
        if (!in_array($role, ['ADMIN', 'TEACHER', 'STUDENT'], true) || !preg_match('/^[A-Za-z0-9_.-]{3,40}$/', $user) || strlen($pass) < 8) flash('error', 'Username must be 3–40 letters/digits and the password at least 8 characters.');
        elseif ($role !== 'ADMIN' && ($name === '' || $code === '')) flash('error', 'Name and ' . ($role === 'TEACHER' ? 'employee code' : 'roll number') . ' are required.');
        elseif ($role === 'STUDENT' && !$classId) flash('error', 'Choose a class for the student.');
        else {
            try {
                $pdo->beginTransaction();
                $pdo->prepare('INSERT INTO users (username,password_hash,role) VALUES (?,?,?)')->execute([$user, password_hash($pass, PASSWORD_DEFAULT), $role]); $uid = (int)$pdo->lastInsertId();
                if ($role === 'TEACHER') $pdo->prepare('INSERT INTO teachers (user_id,employee_code,full_name) VALUES (?,?,?)')->execute([$uid, $code, $name]);
                if ($role === 'STUDENT') $pdo->prepare('INSERT INTO students (user_id,roll_no,full_name,class_id) VALUES (?,?,?,?)')->execute([$uid, $code, $name, $classId]);
                audit($pdo, 'USER_CREATE', 'users', $uid, "$role $user"); $pdo->commit(); flash('ok', "User $user created.");
            } catch (PDOException $e) { if ($pdo->inTransaction()) $pdo->rollBack(); flash('error', 'Could not create the user: the username, roll number or employee code probably already exists.'); }
        }
        redirect($back);
    }
    if ($form === 'toggle_user') {
        $uid = (int)$_POST['user_id']; if ($uid === (int)$_SESSION['user_id']) { flash('error', 'You cannot deactivate your own account.'); redirect($back); }
        $pdo->prepare('UPDATE users SET is_active = 1 - is_active WHERE user_id=?')->execute([$uid]); audit($pdo, 'USER_TOGGLE', 'users', $uid); flash('ok', 'User status changed.'); redirect($back);
    }
    if ($form === 'reset_password') {
        $uid = (int)$_POST['user_id']; $pass = $_POST['password'] ?? '';
        if (strlen($pass) < 8) flash('error', 'New password must be at least 8 characters.');
        else { $pdo->prepare('UPDATE users SET password_hash=? WHERE user_id=?')->execute([password_hash($pass, PASSWORD_DEFAULT), $uid]); audit($pdo, 'PASSWORD_RESET', 'users', $uid); flash('ok', 'Password reset.'); }
        redirect($back);
    }
    if ($form === 'add_class') {
        $name = trim($_POST['class_name'] ?? ''); $year = trim($_POST['academic_year'] ?? '');
        if ($name === '' || $year === '') flash('error', 'Class name and academic year are required.');
        else { $pdo->prepare('INSERT INTO classes (class_name,section,academic_year) VALUES (?,?,?)')->execute([$name, trim($_POST['section'] ?? '') ?: null, $year]); audit($pdo, 'CLASS_CREATE', 'classes', $pdo->lastInsertId(), $name); flash('ok', 'Class added.'); }
        redirect($back);
    }
    if ($form === 'delete_class') { try_delete($pdo, 'DELETE FROM classes WHERE class_id=?', (int)$_POST['id'], 'class'); redirect($back); }
    if ($form === 'add_subject') {
        $code = trim($_POST['subject_code'] ?? ''); $name = trim($_POST['subject_name'] ?? '');
        if ($code === '' || $name === '') flash('error', 'Subject code and name are required.');
        else try { $pdo->prepare('INSERT INTO subjects (subject_code,subject_name) VALUES (?,?)')->execute([$code, $name]); audit($pdo, 'SUBJECT_CREATE', 'subjects', $pdo->lastInsertId(), $name); flash('ok', 'Subject added.'); } catch (PDOException $e) { flash('error', 'That subject code already exists.'); }
        redirect($back);
    }
    if ($form === 'delete_subject') { try_delete($pdo, 'DELETE FROM subjects WHERE subject_id=?', (int)$_POST['id'], 'subject'); redirect($back); }
    if ($form === 'add_allocation') {
        try { $pdo->prepare('INSERT INTO teacher_subjects (teacher_id,class_id,subject_id) VALUES (?,?,?)')->execute([(int)$_POST['teacher_id'], (int)$_POST['class_id'], (int)$_POST['subject_id']]); audit($pdo, 'ALLOCATION_CREATE', 'teacher_subjects', $pdo->lastInsertId()); flash('ok', 'Allocation added.'); }
        catch (PDOException $e) { flash('error', 'That allocation already exists (or an item was not found).'); }
        redirect($back);
    }
    if ($form === 'delete_allocation') { try_delete($pdo, 'DELETE FROM teacher_subjects WHERE allocation_id=?', (int)$_POST['id'], 'allocation'); redirect($back); }
    if ($form === 'enroll_class') {
        $classId = (int)$_POST['class_id']; $subId = (int)$_POST['subject_id'];
        $q = $pdo->prepare('SELECT student_id FROM students WHERE class_id=?'); $q->execute([$classId]); $n = 0;
        $q2 = $pdo->prepare('SELECT academic_year FROM classes WHERE class_id=?'); $q2->execute([$classId]); $year = $q2->fetchColumn();
        $chk = $pdo->prepare('SELECT 1 FROM enrollments WHERE student_id=? AND subject_id=? AND academic_year=?'); $ins = $pdo->prepare('INSERT INTO enrollments (student_id,subject_id,academic_year) VALUES (?,?,?)');
        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $stu) { $chk->execute([$stu, $subId, $year]); if (!$chk->fetch()) { $ins->execute([$stu, $subId, $year]); $n++; } }
        audit($pdo, 'ENROLL_CLASS', 'enrollments', "$classId|$subId", "$n new"); flash('ok', "$n student(s) enrolled."); redirect($back);
    }
    if ($form === 'unenroll') {
        try_delete($pdo, 'DELETE FROM enrollments WHERE enrollment_id=?', (int)$_POST['id'], 'enrolment'); redirect($back);
    }
    if ($form === 'decide_leave') {
        $lid = (int)$_POST['leave_id']; $approve = ($_POST['decision'] ?? '') === 'approve'; $note = trim($_POST['note'] ?? '');
        $q = $pdo->prepare("SELECT * FROM leave_requests WHERE leave_id=? AND status='PENDING'"); $q->execute([$lid]); $lv = $q->fetch();
        if (!$lv) { flash('error', 'Leave request not found.'); redirect($back); }
        $pdo->beginTransaction();
        $pdo->prepare('UPDATE leave_requests SET status=?, decided_by=?, decided_at=?, decision_note=? WHERE leave_id=?')->execute([$approve ? 'APPROVED' : 'REJECTED', $_SESSION['user_id'], date('Y-m-d H:i:s'), $note, $lid]);
        audit($pdo, $approve ? 'LEAVE_APPROVE' : 'LEAVE_REJECT', 'leave_requests', $lid, $note);
        $n = $approve ? apply_leave_to_existing($pdo, $lv) : 0; $pdo->commit();
        flash('ok', 'Leave ' . ($approve ? 'approved' . ($n ? " ($n saved absence(s) changed to Leave)" : '') : 'rejected') . '.'); redirect($back);
    }
    if ($form === 'settings') {
        $t = (float)($_POST['threshold'] ?? 75); $days = (int)($_POST['edit_window_days'] ?? 7);
        if ($t < 1 || $t > 100 || $days < 0 || $days > 365) { flash('error', 'Threshold must be 1–100 and the edit window 0–365 days.'); redirect($back); }
        $up = $pdo->prepare('UPDATE settings SET setting_value=? WHERE setting_key=?');
        foreach (['threshold' => (string)$t, 'edit_window_days' => (string)$days, 'leave_counts_as_present' => isset($_POST['leave_counts_as_present']) ? '1' : '0'] as $k => $v) {
            $up->execute([$v, $k]); if ($up->rowCount() === 0) { $chk = $pdo->prepare('SELECT 1 FROM settings WHERE setting_key=?'); $chk->execute([$k]); if (!$chk->fetch()) $pdo->prepare('INSERT INTO settings (setting_key,setting_value) VALUES (?,?)')->execute([$k, $v]); }
        }
        audit($pdo, 'SETTINGS_UPDATE', 'settings', 'all', "threshold=$t, window=$days"); flash('ok', 'Settings saved.'); redirect($back);
    }
    if ($form === 'edit_attendance') {
        $sid = (int)$_POST['session_id']; $reason = trim($_POST['reason'] ?? '');
        if ($reason === '') { flash('error', 'A reason is required.'); redirect('admin.php?tab=sessions&session_id=' . $sid); }
        $n = 0; $pdo->beginTransaction();
        foreach (($_POST['status'] ?? []) as $stu => $status) if (in_array($status, STATUSES, true) && set_attendance($pdo, $sid, (int)$stu, $status, 'Admin: ' . $reason)) $n++;
        $pdo->commit(); flash('ok', $n ? "$n record(s) updated and logged." : 'Nothing was changed.'); redirect('admin.php?tab=sessions&session_id=' . $sid);
    }
}

page_header('Administrator');

// ---------- home ----------
if ($tab === 'home') {
    $counts = [];
    foreach (['Students' => 'students', 'Teachers' => 'teachers', 'Classes' => 'classes', 'Subjects' => 'subjects', 'Sessions' => 'sessions'] as $label => $table) $counts[$label] = (int)$pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
    $counts['Pending leaves'] = (int)$pdo->query("SELECT COUNT(*) FROM leave_requests WHERE status='PENDING'")->fetchColumn();
    echo '<h1>Administrator Dashboard</h1><p class="muted">Welcome, ' . h($_SESSION['username']) . '.</p><div class="stats">';
    foreach ($counts as $label => $n) echo '<div class="stat card"><span>' . h($label) . '</span><strong>' . $n . '</strong></div>';
    echo '</div><section class="card"><h2>What you can do here</h2><p>Add users, classes, subjects, teacher allocations and enrolments; decide leave requests; edit any attendance record with a logged reason; change the shortage threshold; and read the audit log. Reports are under <a href="reports.php">Reports</a>.</p></section>';
}

// ---------- users ----------
if ($tab === 'users') {
    echo '<h1>Users</h1><section class="card"><h2>Add a user</h2><form method="post"><input type="hidden" name="form" value="create_user"><input type="hidden" name="back" value="users">' . csrf_field() . '<div class="form-grid"><div><label>Role</label><select name="role"><option>STUDENT</option><option>TEACHER</option><option>ADMIN</option></select></div><div><label>Username</label><input name="username" required></div><div><label>Full name (not needed for ADMIN)</label><input name="full_name"></div><div><label>Roll no. (student) / Employee code (teacher)</label><input name="code"></div><div><label>Class (students only)</label><select name="class_id"><option value="">—</option>';
    foreach (all_classes($pdo) as $c) echo '<option value="' . (int)$c['class_id'] . '">' . h(class_label($c)) . '</option>';
    echo '</select></div><div><label>Initial password (min 8)</label><input type="password" name="password" required minlength="8"></div></div><button>Create user</button></form></section>';
    $rows = $pdo->query("SELECT u.user_id,u.username,u.role,u.is_active,COALESCE(s.full_name,t.full_name,'') AS full_name,COALESCE(s.roll_no,t.employee_code,'') AS code FROM users u LEFT JOIN students s ON s.user_id=u.user_id LEFT JOIN teachers t ON t.user_id=u.user_id ORDER BY u.role,u.username")->fetchAll();
    echo '<section class="card"><h2>All users</h2><div class="table-wrap"><table><thead><tr><th>Username</th><th>Role</th><th>Name</th><th>Code</th><th>Active</th><th>Actions</th></tr></thead><tbody>';
    foreach ($rows as $r) {
        echo '<tr><td>' . h($r['username']) . '</td><td>' . h($r['role']) . '</td><td>' . h($r['full_name']) . '</td><td>' . h($r['code']) . '</td><td>' . ($r['is_active'] ? 'Yes' : '<span class="badge bad">No</span>') . '</td><td class="inline">';
        echo '<form method="post"><input type="hidden" name="form" value="toggle_user"><input type="hidden" name="back" value="users"><input type="hidden" name="user_id" value="' . (int)$r['user_id'] . '">' . csrf_field() . '<button class="secondary small">' . ($r['is_active'] ? 'Deactivate' : 'Activate') . '</button></form>';
        echo '<form method="post"><input type="hidden" name="form" value="reset_password"><input type="hidden" name="back" value="users"><input type="hidden" name="user_id" value="' . (int)$r['user_id'] . '">' . csrf_field() . '<input type="password" name="password" placeholder="new password" minlength="8" required><button class="secondary small">Reset</button></form></td></tr>';
    }
    echo '</tbody></table></div></section>';
}

// ---------- academic ----------
if ($tab === 'academic') {
    $classes = all_classes($pdo); $subjects = all_subjects($pdo);
    $teachers = $pdo->query('SELECT teacher_id,full_name,employee_code FROM teachers ORDER BY full_name')->fetchAll();
    $del = function ($form, $id) { return '<form method="post" class="inline"><input type="hidden" name="form" value="' . $form . '"><input type="hidden" name="back" value="academic"><input type="hidden" name="id" value="' . (int)$id . '">' . csrf_field() . '<button class="secondary small" onclick="return confirm(\'Delete?\')">Delete</button></form>'; };
    echo '<h1>Classes, subjects, allocations and enrolments</h1>';
    echo '<section class="card"><h2>Classes</h2><form method="post"><input type="hidden" name="form" value="add_class"><input type="hidden" name="back" value="academic">' . csrf_field() . '<div class="form-grid"><div><label>Class name</label><input name="class_name" required></div><div><label>Section</label><input name="section"></div><div><label>Academic year</label><input name="academic_year" placeholder="2026-27" required></div></div><button>Add class</button></form><table><thead><tr><th>Class</th><th>Year</th><th></th></tr></thead><tbody>';
    foreach ($classes as $c) echo '<tr><td>' . h(class_label($c)) . '</td><td>' . h($c['academic_year']) . '</td><td>' . $del('delete_class', $c['class_id']) . '</td></tr>';
    echo '</tbody></table></section>';
    echo '<section class="card"><h2>Subjects</h2><form method="post"><input type="hidden" name="form" value="add_subject"><input type="hidden" name="back" value="academic">' . csrf_field() . '<div class="form-grid"><div><label>Code</label><input name="subject_code" required></div><div><label>Name</label><input name="subject_name" required></div></div><button>Add subject</button></form><table><thead><tr><th>Code</th><th>Name</th><th></th></tr></thead><tbody>';
    foreach ($subjects as $s) echo '<tr><td>' . h($s['subject_code']) . '</td><td>' . h($s['subject_name']) . '</td><td>' . $del('delete_subject', $s['subject_id']) . '</td></tr>';
    echo '</tbody></table></section>';
    echo '<section class="card"><h2>Teacher allocations</h2><form method="post"><input type="hidden" name="form" value="add_allocation"><input type="hidden" name="back" value="academic">' . csrf_field() . '<div class="form-grid"><div><label>Teacher</label><select name="teacher_id" required>';
    foreach ($teachers as $t) echo '<option value="' . (int)$t['teacher_id'] . '">' . h($t['full_name'] . ' (' . $t['employee_code'] . ')') . '</option>';
    echo '</select></div><div><label>Class</label><select name="class_id" required>'; foreach ($classes as $c) echo '<option value="' . (int)$c['class_id'] . '">' . h(class_label($c)) . '</option>';
    echo '</select></div><div><label>Subject</label><select name="subject_id" required>'; foreach ($subjects as $s) echo '<option value="' . (int)$s['subject_id'] . '">' . h($s['subject_name']) . '</option>';
    echo '</select></div></div><button>Add allocation</button></form><table><thead><tr><th>Teacher</th><th>Class</th><th>Subject</th><th></th></tr></thead><tbody>';
    foreach ($pdo->query('SELECT ts.allocation_id,t.full_name,c.class_name,c.section,s.subject_name FROM teacher_subjects ts JOIN teachers t ON t.teacher_id=ts.teacher_id JOIN classes c ON c.class_id=ts.class_id JOIN subjects s ON s.subject_id=ts.subject_id ORDER BY t.full_name,c.class_name,s.subject_name') as $a)
        echo '<tr><td>' . h($a['full_name']) . '</td><td>' . h(class_label($a)) . '</td><td>' . h($a['subject_name']) . '</td><td>' . $del('delete_allocation', $a['allocation_id']) . '</td></tr>';
    echo '</tbody></table></section>';
    echo '<section class="card"><h2>Enrolments</h2><p class="muted">Students only appear in a teacher\'s list for subjects they are enrolled in.</p><form method="post"><input type="hidden" name="form" value="enroll_class"><input type="hidden" name="back" value="academic">' . csrf_field() . '<div class="form-grid"><div><label>Enrol every student of class</label><select name="class_id">'; foreach ($classes as $c) echo '<option value="' . (int)$c['class_id'] . '">' . h(class_label($c)) . '</option>';
    echo '</select></div><div><label>in subject</label><select name="subject_id">'; foreach ($subjects as $s) echo '<option value="' . (int)$s['subject_id'] . '">' . h($s['subject_name']) . '</option>';
    echo '</select></div></div><button>Enrol class</button></form><table><thead><tr><th>Student</th><th>Subject</th><th>Year</th><th></th></tr></thead><tbody>';
    foreach ($pdo->query('SELECT e.enrollment_id,s.roll_no,s.full_name,sub.subject_name,e.academic_year FROM enrollments e JOIN students s ON s.student_id=e.student_id JOIN subjects sub ON sub.subject_id=e.subject_id ORDER BY s.roll_no,sub.subject_name LIMIT 300') as $e)
        echo '<tr><td>' . h($e['roll_no'] . ' ' . $e['full_name']) . '</td><td>' . h($e['subject_name']) . '</td><td>' . h($e['academic_year']) . '</td><td>' . $del('unenroll', $e['enrollment_id']) . '</td></tr>';
    echo '</tbody></table></section>';
}

// ---------- leaves ----------
if ($tab === 'leaves') {
    echo '<h1>Leave requests</h1><section class="card"><h2>Pending</h2>';
    $pend = $pdo->query("SELECT lr.*,s.full_name,s.roll_no FROM leave_requests lr JOIN students s ON s.student_id=lr.student_id WHERE lr.status='PENDING' ORDER BY lr.created_at")->fetchAll();
    if (!$pend) echo '<p class="muted">No pending requests.</p>';
    foreach ($pend as $l) echo '<form method="post" class="req"><input type="hidden" name="form" value="decide_leave"><input type="hidden" name="back" value="leaves"><input type="hidden" name="leave_id" value="' . (int)$l['leave_id'] . '">' . csrf_field() . '<p><strong>' . h($l['full_name']) . '</strong> (' . h($l['roll_no']) . ') · ' . h($l['from_date']) . ' to ' . h($l['to_date']) . '<br><span class="muted">' . h($l['reason']) . '</span></p><input name="note" placeholder="Note (optional)" maxlength="200"><button name="decision" value="approve">Approve</button> <button name="decision" value="reject" class="secondary">Reject</button></form>';
    echo '</section><section class="card"><h2>Recently decided</h2><div class="table-wrap"><table><thead><tr><th>Student</th><th>Dates</th><th>Status</th><th>Note</th></tr></thead><tbody>';
    foreach ($pdo->query("SELECT lr.*,s.full_name FROM leave_requests lr JOIN students s ON s.student_id=lr.student_id WHERE lr.status<>'PENDING' ORDER BY lr.leave_id DESC LIMIT 50") as $l)
        echo '<tr><td>' . h($l['full_name']) . '</td><td>' . h($l['from_date'] . ' → ' . $l['to_date']) . '</td><td>' . status_badge($l['status']) . '</td><td>' . h($l['decision_note']) . '</td></tr>';
    echo '</tbody></table></div></section>';
}

// ---------- sessions (admin edit of any record) ----------
if ($tab === 'sessions') {
    echo '<h1>Edit attendance (administrator)</h1>'; $sid = (int)($_GET['session_id'] ?? 0);
    if ($sid) {
        $q = $pdo->prepare('SELECT ses.*,sub.subject_name,c.class_name,c.section FROM sessions ses JOIN subjects sub ON sub.subject_id=ses.subject_id JOIN classes c ON c.class_id=ses.class_id WHERE ses.session_id=?'); $q->execute([$sid]); $ses = $q->fetch();
        if ($ses) {
            $q = $pdo->prepare('SELECT a.student_id,a.status,s.roll_no,s.full_name FROM attendance a JOIN students s ON s.student_id=a.student_id WHERE a.session_id=? ORDER BY s.roll_no'); $q->execute([$sid]);
            echo '<section class="card"><h2>' . h(class_label($ses) . ' — ' . $ses['subject_name'] . ' · ' . $ses['session_date']) . '</h2><form method="post"><input type="hidden" name="form" value="edit_attendance"><input type="hidden" name="session_id" value="' . $sid . '">' . csrf_field() . '<table><thead><tr><th>Roll</th><th>Student</th><th>Status</th></tr></thead><tbody>';
            foreach ($q->fetchAll() as $r) echo '<tr><td>' . h($r['roll_no']) . '</td><td>' . h($r['full_name']) . '</td><td>' . status_select('status[' . (int)$r['student_id'] . ']', $r['status']) . '</td></tr>';
            echo '</tbody></table><label>Reason (required)</label><input name="reason" required maxlength="200"><button>Save changes</button> <a href="admin.php?tab=sessions">Back</a></form></section>';
        }
    } else {
        echo '<section class="card"><h2>Recent sessions</h2><table><thead><tr><th>Date</th><th>Class</th><th>Subject</th><th></th></tr></thead><tbody>';
        foreach ($pdo->query('SELECT ses.session_id,ses.session_date,c.class_name,c.section,sub.subject_name FROM sessions ses JOIN classes c ON c.class_id=ses.class_id JOIN subjects sub ON sub.subject_id=ses.subject_id ORDER BY ses.session_date DESC, ses.session_id DESC LIMIT 100') as $r)
            echo '<tr><td>' . h($r['session_date']) . '</td><td>' . h(class_label($r)) . '</td><td>' . h($r['subject_name']) . '</td><td><a href="admin.php?tab=sessions&session_id=' . (int)$r['session_id'] . '">Open</a></td></tr>';
        echo '</tbody></table></section>';
    }
}

// ---------- settings ----------
if ($tab === 'settings') {
    echo '<h1>Settings</h1><section class="card"><form method="post"><input type="hidden" name="form" value="settings"><input type="hidden" name="back" value="settings">' . csrf_field() . '<label>Minimum attendance % (shortage threshold)</label><input type="number" step="0.5" min="1" max="100" name="threshold" value="' . h(threshold($pdo)) . '"><label>Teachers can edit a record for this many days</label><input type="number" min="0" max="365" name="edit_window_days" value="' . h(setting($pdo, 'edit_window_days', 7)) . '"><label><input type="checkbox" name="leave_counts_as_present" value="1" style="width:auto"' . (setting($pdo, 'leave_counts_as_present', '1') === '1' ? ' checked' : '') . '> Approved leave counts as attended</label><button>Save settings</button></form></section>';
}

// ---------- audit ----------
if ($tab === 'audit') {
    echo '<h1>Audit log</h1><section class="card"><div class="table-wrap"><table><thead><tr><th>When</th><th>Who</th><th>Action</th><th>What</th><th>Details</th></tr></thead><tbody>';
    foreach ($pdo->query('SELECT l.*,u.username FROM audit_logs l JOIN users u ON u.user_id=l.actor_user_id ORDER BY l.log_id DESC LIMIT 200') as $l)
        echo '<tr><td>' . h($l['created_at']) . '</td><td>' . h($l['username']) . '</td><td>' . h($l['action']) . '</td><td>' . h($l['entity_name'] . ' #' . $l['entity_id']) . '</td><td>' . h($l['reason']) . '</td></tr>';
    echo '</tbody></table></div><p class="muted small">Showing the latest 200 entries.</p></section>';
}
page_footer();
