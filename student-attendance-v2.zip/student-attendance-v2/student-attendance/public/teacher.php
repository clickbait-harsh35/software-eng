<?php
require_once __DIR__ . '/../includes/lib.php';
require_role('TEACHER');
$teacher = current_teacher($pdo);
if (!$teacher) exit('Teacher profile is missing. Ask the administrator or run setup.php again.');
$tid = (int)$teacher['teacher_id'];
$tab = $_GET['tab'] ?? 'mark';

// ---------- AJAX: student list for the marking form ----------
if (($_GET['action'] ?? '') === 'students') {
    $classId = (int)($_GET['class_id'] ?? 0); $subjectId = (int)($_GET['subject_id'] ?? 0); $date = $_GET['date'] ?? '';
    if (!teacher_owns($pdo, $tid, $classId, $subjectId) || !valid_date($date)) { http_response_code(403); exit('Access denied.'); }
    $q = $pdo->prepare('SELECT session_id FROM sessions WHERE class_id=? AND subject_id=? AND session_date=?'); $q->execute([$classId, $subjectId, $date]); $existing = $q->fetchColumn();
    if ($existing) { echo '<div class="alert error">Attendance for this class, subject and date is already saved. Use <a href="teacher.php?tab=edit&session_id=' . (int)$existing . '">Edit records</a> to change it.</div>'; exit; }
    $q = $pdo->prepare('SELECT s.student_id,s.roll_no,s.full_name FROM students s JOIN enrollments e ON e.student_id=s.student_id WHERE s.class_id=? AND e.subject_id=? ORDER BY s.roll_no'); $q->execute([$classId, $subjectId]); $students = $q->fetchAll();
    if (!$students) { echo '<p>No enrolled students found.</p>'; exit; }
    echo '<h3>Mark each student <span class="muted small">(everyone starts as Present; students with approved leave start as Leave)</span></h3><div class="table-wrap"><table><thead><tr><th>Roll No.</th><th>Student</th><th>Status</th></tr></thead><tbody>';
    foreach ($students as $s) {
        $default = on_approved_leave($pdo, $s['student_id'], $date) ? 'LEAVE' : 'PRESENT';
        echo '<tr><td>' . h($s['roll_no']) . '</td><td>' . h($s['full_name']) . '</td><td>' . status_select('status[' . (int)$s['student_id'] . ']', $default, 'attendanceForm') . '</td></tr>';
    }
    echo '</tbody></table></div><button type="submit" form="attendanceForm">Save attendance</button>'; exit;
}

// ---------- POST handlers ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $form = $_POST['form'] ?? '';

    if ($form === 'attendance') {
        $classId = (int)($_POST['class_id'] ?? 0); $subjectId = (int)($_POST['subject_id'] ?? 0); $date = $_POST['session_date'] ?? '';
        if (!teacher_owns($pdo, $tid, $classId, $subjectId) || !valid_date($date)) { flash('error', 'Invalid class, subject or date.'); redirect('teacher.php'); }
        if ($date > date('Y-m-d')) { flash('error', 'You cannot record attendance for a future date.'); redirect('teacher.php'); }
        $q = $pdo->prepare('SELECT session_id FROM sessions WHERE class_id=? AND subject_id=? AND session_date=?'); $q->execute([$classId, $subjectId, $date]);
        if ($existing = $q->fetchColumn()) { flash('error', 'Attendance for that date is already saved. Edit it instead.'); redirect('teacher.php?tab=edit&session_id=' . (int)$existing); }
        $q = $pdo->prepare('SELECT s.student_id FROM students s JOIN enrollments e ON e.student_id=s.student_id WHERE s.class_id=? AND e.subject_id=?'); $q->execute([$classId, $subjectId]); $ids = array_map('intval', $q->fetchAll(PDO::FETCH_COLUMN));
        if (!$ids) { flash('error', 'No enrolled students found for this class and subject.'); redirect('teacher.php'); }
        try {
            $pdo->beginTransaction();
            $pdo->prepare("INSERT INTO sessions (class_id,subject_id,teacher_id,session_date,starts_at,ends_at,status) VALUES (?,?,?,?,?,?,'CLOSED')")
                ->execute([$classId, $subjectId, $tid, $date, $date . ' 00:00:00', $date . ' 23:59:59']);
            $sid = (int)$pdo->lastInsertId();
            $ins = $pdo->prepare('INSERT INTO attendance (session_id,student_id,status,marked_by) VALUES (?,?,?,?)');
            foreach ($ids as $studentId) {
                $status = $_POST['status'][$studentId] ?? '';
                if (!in_array($status, STATUSES, true)) throw new RuntimeException('Choose a status for every student.');
                $ins->execute([$sid, $studentId, $status, $_SESSION['user_id']]);
            }
            audit($pdo, 'SESSION_CREATE', 'sessions', $sid, count($ids) . ' students marked');
            $pdo->commit(); flash('ok', 'Attendance saved successfully.');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('error', 'Could not save attendance: ' . ($e instanceof RuntimeException ? $e->getMessage() : 'a database error occurred.'));
        }
        redirect('teacher.php');
    }

    if ($form === 'edit_attendance') {
        $sid = (int)($_POST['session_id'] ?? 0); $reason = trim($_POST['reason'] ?? '');
        $q = $pdo->prepare('SELECT * FROM sessions WHERE session_id=?'); $q->execute([$sid]); $ses = $q->fetch();
        if (!$ses || !teacher_owns($pdo, $tid, $ses['class_id'], $ses['subject_id'])) { http_response_code(403); exit('Access denied.'); }
        $days = (int)setting($pdo, 'edit_window_days', 7);
        if ((time() - strtotime($ses['session_date'])) > $days * 86400 + 86399) { flash('error', "This record is older than $days days. Ask the administrator to change it."); redirect('teacher.php?tab=edit'); }
        if ($reason === '') { flash('error', 'A reason is required when editing attendance.'); redirect('teacher.php?tab=edit&session_id=' . $sid); }
        $changed = 0; $pdo->beginTransaction();
        try {
            foreach (($_POST['status'] ?? []) as $studentId => $status) if (in_array($status, STATUSES, true) && set_attendance($pdo, $sid, (int)$studentId, $status, $reason)) $changed++;
            $pdo->commit(); flash('ok', $changed ? "$changed record(s) updated and logged." : 'Nothing was changed.');
        } catch (Throwable $e) { $pdo->rollBack(); flash('error', 'Could not update attendance.'); }
        redirect('teacher.php?tab=edit&session_id=' . $sid);
    }

    if ($form === 'decide_correction') {
        $cid = (int)($_POST['correction_id'] ?? 0); $approve = ($_POST['decision'] ?? '') === 'approve'; $note = trim($_POST['note'] ?? '');
        $q = $pdo->prepare("SELECT cr.*, ses.class_id, ses.subject_id, ses.session_id FROM correction_requests cr JOIN attendance a ON a.attendance_id=cr.attendance_id JOIN sessions ses ON ses.session_id=a.session_id WHERE cr.correction_id=? AND cr.status='PENDING'");
        $q->execute([$cid]); $cr = $q->fetch();
        if (!$cr || !teacher_owns($pdo, $tid, $cr['class_id'], $cr['subject_id'])) { flash('error', 'Request not found.'); redirect('teacher.php?tab=requests'); }
        $pdo->beginTransaction();
        if ($approve) set_attendance($pdo, $cr['session_id'], $cr['student_id'], $cr['requested_status'], 'Correction request #' . $cid . ': ' . $cr['reason'], 'CORRECTION_APPROVED');
        $pdo->prepare('UPDATE correction_requests SET status=?, decided_by=?, decided_at=?, decision_note=? WHERE correction_id=?')->execute([$approve ? 'APPROVED' : 'REJECTED', $_SESSION['user_id'], date('Y-m-d H:i:s'), $note, $cid]);
        audit($pdo, $approve ? 'CORRECTION_APPROVE' : 'CORRECTION_REJECT', 'correction_requests', $cid, $note);
        $pdo->commit(); flash('ok', 'Correction request ' . ($approve ? 'approved and attendance updated.' : 'rejected.')); redirect('teacher.php?tab=requests');
    }

    if ($form === 'decide_leave') {
        $lid = (int)($_POST['leave_id'] ?? 0); $approve = ($_POST['decision'] ?? '') === 'approve'; $note = trim($_POST['note'] ?? '');
        // A teacher may decide leave only for students in a class they teach.
        $q = $pdo->prepare("SELECT lr.* FROM leave_requests lr JOIN students s ON s.student_id=lr.student_id WHERE lr.leave_id=? AND lr.status='PENDING' AND s.class_id IN (SELECT class_id FROM teacher_subjects WHERE teacher_id=?)");
        $q->execute([$lid, $tid]); $lv = $q->fetch();
        if (!$lv) { flash('error', 'Leave request not found.'); redirect('teacher.php?tab=requests'); }
        $pdo->beginTransaction();
        $pdo->prepare('UPDATE leave_requests SET status=?, decided_by=?, decided_at=?, decision_note=? WHERE leave_id=?')->execute([$approve ? 'APPROVED' : 'REJECTED', $_SESSION['user_id'], date('Y-m-d H:i:s'), $note, $lid]);
        audit($pdo, $approve ? 'LEAVE_APPROVE' : 'LEAVE_REJECT', 'leave_requests', $lid, $note);
        $n = $approve ? apply_leave_to_existing($pdo, $lv) : 0;
        $pdo->commit(); flash('ok', 'Leave ' . ($approve ? 'approved' . ($n ? " ($n saved absence(s) changed to Leave)" : '') : 'rejected') . '.'); redirect('teacher.php?tab=requests');
    }
}

$allocations = teacher_allocations($pdo, $tid);
page_header('Teacher Dashboard');

// ---------- TAB: mark ----------
if ($tab === 'mark') {
    echo '<h1>Mark attendance</h1><p class="muted">Welcome, ' . h($teacher['full_name']) . '. Record attendance for your allocated subjects.</p>';
    echo '<section class="card"><form method="post" id="attendanceForm"><input type="hidden" name="form" value="attendance">' . csrf_field() . '<div class="form-grid"><div><label>Class / Subject</label><select id="allocation" required><option value="">Select allocation</option>';
    foreach ($allocations as $a) echo '<option value="' . (int)$a['class_id'] . '|' . (int)$a['subject_id'] . '">' . h(class_label($a) . ' — ' . $a['subject_name']) . '</option>';
    echo '</select><input type="hidden" name="class_id" id="class_id"><input type="hidden" name="subject_id" id="subject_id"></div><div><label>Session date</label><input type="date" name="session_date" id="session_date" value="' . date('Y-m-d') . '" max="' . date('Y-m-d') . '" required></div></div><button type="button" id="loadStudents">Load student list</button><div id="studentList" class="student-list"></div></form></section>';
    echo '<script>document.getElementById("loadStudents").addEventListener("click",async()=>{const v=document.getElementById("allocation").value;if(!v){alert("Select a class and subject first.");return;}const [c,s]=v.split("|");document.getElementById("class_id").value=c;document.getElementById("subject_id").value=s;const d=document.getElementById("session_date").value;const box=document.getElementById("studentList");box.innerHTML="Loading...";const res=await fetch("?action=students&class_id="+encodeURIComponent(c)+"&subject_id="+encodeURIComponent(s)+"&date="+encodeURIComponent(d));box.innerHTML=await res.text();});</script>';
}

// ---------- TAB: edit ----------
if ($tab === 'edit') {
    echo '<h1>Edit attendance records</h1><p class="muted">Every change needs a reason and is written to the audit log. Records can be edited for ' . (int)setting($pdo, 'edit_window_days', 7) . ' days.</p>';
    $sid = (int)($_GET['session_id'] ?? 0);
    if ($sid) {
        $q = $pdo->prepare('SELECT ses.*, sub.subject_name, c.class_name, c.section FROM sessions ses JOIN subjects sub ON sub.subject_id=ses.subject_id JOIN classes c ON c.class_id=ses.class_id WHERE ses.session_id=?'); $q->execute([$sid]); $ses = $q->fetch();
        if (!$ses || !teacher_owns($pdo, $tid, $ses['class_id'], $ses['subject_id'])) { echo '<p>Session not found.</p>'; page_footer(); exit; }
        $q = $pdo->prepare('SELECT a.student_id,a.status,s.roll_no,s.full_name FROM attendance a JOIN students s ON s.student_id=a.student_id WHERE a.session_id=? ORDER BY s.roll_no'); $q->execute([$sid]);
        echo '<section class="card"><h2>' . h(class_label($ses) . ' — ' . $ses['subject_name']) . ' · ' . h($ses['session_date']) . '</h2><form method="post"><input type="hidden" name="form" value="edit_attendance"><input type="hidden" name="session_id" value="' . $sid . '">' . csrf_field() . '<div class="table-wrap"><table><thead><tr><th>Roll No.</th><th>Student</th><th>Status</th></tr></thead><tbody>';
        foreach ($q->fetchAll() as $r) echo '<tr><td>' . h($r['roll_no']) . '</td><td>' . h($r['full_name']) . '</td><td>' . status_select('status[' . (int)$r['student_id'] . ']', $r['status']) . '</td></tr>';
        echo '</tbody></table></div><label>Reason for change (required)</label><input name="reason" required maxlength="200" placeholder="e.g. Marked wrong student by mistake"><button>Save changes</button> <a href="teacher.php?tab=edit">Back</a></form></section>';
    } else {
        $q = $pdo->prepare('SELECT ses.session_id,ses.session_date,c.class_name,c.section,sub.subject_name FROM sessions ses JOIN classes c ON c.class_id=ses.class_id JOIN subjects sub ON sub.subject_id=ses.subject_id WHERE ses.teacher_id=? OR ses.class_id IN (SELECT class_id FROM teacher_subjects WHERE teacher_id=? AND subject_id=ses.subject_id) ORDER BY ses.session_date DESC, ses.session_id DESC LIMIT 60');
        $q->execute([$tid, $tid]); $rows = $q->fetchAll();
        echo '<section class="card"><h2>Recent sessions</h2><div class="table-wrap"><table><thead><tr><th>Date</th><th>Class</th><th>Subject</th><th></th></tr></thead><tbody>';
        foreach ($rows as $r) echo '<tr><td>' . h($r['session_date']) . '</td><td>' . h(class_label($r)) . '</td><td>' . h($r['subject_name']) . '</td><td><a href="teacher.php?tab=edit&session_id=' . (int)$r['session_id'] . '">Open</a></td></tr>';
        if (!$rows) echo '<tr><td colspan="4" class="muted">No sessions yet.</td></tr>';
        echo '</tbody></table></div></section>';
    }
}

// ---------- TAB: requests ----------
if ($tab === 'requests') {
    echo '<h1>Requests</h1>';
    $q = $pdo->prepare("SELECT lr.*, s.full_name, s.roll_no FROM leave_requests lr JOIN students s ON s.student_id=lr.student_id WHERE lr.status='PENDING' AND s.class_id IN (SELECT class_id FROM teacher_subjects WHERE teacher_id=?) ORDER BY lr.created_at"); $q->execute([$tid]); $leaves = $q->fetchAll();
    echo '<section class="card"><h2>Pending leave requests</h2>';
    if (!$leaves) echo '<p class="muted">No pending leave requests.</p>';
    foreach ($leaves as $l) echo '<form method="post" class="req"><input type="hidden" name="form" value="decide_leave"><input type="hidden" name="leave_id" value="' . (int)$l['leave_id'] . '">' . csrf_field() . '<p><strong>' . h($l['full_name']) . '</strong> (' . h($l['roll_no']) . ') · ' . h($l['from_date']) . ' to ' . h($l['to_date']) . '<br><span class="muted">' . h($l['reason']) . '</span></p><input name="note" placeholder="Note (optional)" maxlength="200"><button name="decision" value="approve">Approve</button> <button name="decision" value="reject" class="secondary">Reject</button></form>';
    echo '</section>';
    $q = $pdo->prepare("SELECT cr.*, s.full_name, s.roll_no, a.status AS current_status, ses.session_date, sub.subject_name FROM correction_requests cr JOIN attendance a ON a.attendance_id=cr.attendance_id JOIN sessions ses ON ses.session_id=a.session_id JOIN subjects sub ON sub.subject_id=ses.subject_id JOIN students s ON s.student_id=cr.student_id WHERE cr.status='PENDING' AND ses.class_id IN (SELECT class_id FROM teacher_subjects WHERE teacher_id=? AND subject_id=ses.subject_id) ORDER BY cr.created_at"); $q->execute([$tid]); $cors = $q->fetchAll();
    echo '<section class="card"><h2>Pending correction requests</h2>';
    if (!$cors) echo '<p class="muted">No pending correction requests.</p>';
    foreach ($cors as $c) echo '<form method="post" class="req"><input type="hidden" name="form" value="decide_correction"><input type="hidden" name="correction_id" value="' . (int)$c['correction_id'] . '">' . csrf_field() . '<p><strong>' . h($c['full_name']) . '</strong> (' . h($c['roll_no']) . ') · ' . h($c['subject_name']) . ' on ' . h($c['session_date']) . '<br>Currently ' . status_badge($c['current_status']) . ' → asks for ' . status_badge($c['requested_status']) . '<br><span class="muted">' . h($c['reason']) . '</span></p><input name="note" placeholder="Note (optional)" maxlength="200"><button name="decision" value="approve">Approve</button> <button name="decision" value="reject" class="secondary">Reject</button></form>';
    echo '</section>';
}
page_footer();
