<?php
require_once __DIR__ . '/../includes/lib.php';

$action = $_GET['action'] ?? '';
if ($action === 'logout') { $_SESSION = []; session_destroy(); redirect('index.php'); }

$home = ['ADMIN' => 'admin.php', 'TEACHER' => 'teacher.php', 'STUDENT' => 'student.php'];
if (!empty($_SESSION['user_id'])) redirect($home[$_SESSION['role']] ?? 'index.php?action=logout');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'login') {
    verify_csrf();
    $stmt = $pdo->prepare('SELECT user_id,username,password_hash,role,is_active FROM users WHERE username=? LIMIT 1');
    $stmt->execute([trim($_POST['username'] ?? '')]); $u = $stmt->fetch();
    if ($u && (int)$u['is_active'] === 1 && password_verify($_POST['password'] ?? '', $u['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$u['user_id']; $_SESSION['username'] = $u['username']; $_SESSION['role'] = $u['role']; $_SESSION['last_seen'] = time();
        redirect($home[$u['role']]);
    }
    $error = 'Invalid username or password.';
}

page_header('Login');
echo '<section class="login card"><h1>Sign in</h1><p class="muted">Access your attendance dashboard.</p>';
if ($error) echo '<div class="alert error">' . h($error) . '</div>';
echo '<form method="post"><input type="hidden" name="form" value="login">' . csrf_field() . '<label>Username</label><input name="username" required autofocus><label>Password</label><input type="password" name="password" required><button>Login</button></form><p class="muted small">Demo accounts are listed in README.md.</p></section>';
page_footer();
