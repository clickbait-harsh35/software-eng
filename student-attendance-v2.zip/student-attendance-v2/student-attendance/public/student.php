<?php
require_once __DIR__ . '/../includes/lib.php';
require_role('STUDENT');
$st = current_student($pdo);
if (!$st) exit('Student profile is missing. Ask the administrator or run setup.php again.');
$sid = (int)$st['student_id'];
$tab = $_GET['tab'] ?? 'home';
$limit = threshold($pdo);

// ---------- POST handlers ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf(); $form = $_POST['form'] ?? '';

    if ($form === 'leave') {
        $from = $_POST['from_date'] ?? ''; $to = $_POST['to_date'] ?? ''; $reason = trim($_POST['reason'] ?? '');
        if (!valid_date($from) || !valid_date($to) || $to < $from) flash('error', 'Choose a valid date range (the end date cannot be before the start date).');
        elseif ($reason === '') flash('error', 'Please give a reason for the leave.');
        elseif ($to < date('Y-m-d', strtotime('-30 days'))) flash('error', 'Leave can only be requested for the last 30 days or the future.');
        else {
            $q = $pdo->prepare("SELECT COUNT(*) FROM leave_requests WHERE student_id=? AND status IN ('PENDING','APPROVED') AND from_date<=? AND to_date>=?"); $q->execute([$sid, $to, $from]);
            if ($q->fetchColumn()) flash('error', 'You already have a pending or approved leave overlapping these dates.');
            else {
                $pdo->prepare('INSERT INTO leave_requests (student_id,from_date,to_date,reason) VALUES (?,?,?,?)')->execute([$sid, $from, $to, mb_substr($reason, 0, 500)]);
                audit($pdo, 'LEAVE_REQUEST', 'leave_requests', $pdo->lastInsertId(), "$from to $to");
                flash('ok', 'Leave request submitted. A teacher or the administrator will review it.');
            }
        }
        redirect('student.php?tab=leave');
    }
    if ($form === 'cancel_leave') {
        $pdo->prepare("UPDATE leave_requests SET status='CANCELLED' WHERE leave_id=? AND student_id=? AND status='PENDING'")->execute([(int)($_POST['leave_id'] ?? 0), $sid]);
        flash('ok', 'Leave request cancelled.'); redirect('student.php?tab=leave');
    }
    if ($form === 'correction') {
        $aid = (int)($_POST['attendance_id'] ?? 0); $want = $_POST['requested_status'] ?? ''; $reason = trim($_POST['reason'] ?? '');
        $q = $pdo->prepare('SELECT a.attendance_id,a.status FROM attendance a WHERE a.attendance_id=? AND a.student_id=?'); $q->execute([$aid, $sid]); $rec = $q->fetch();
        if (!$rec || !in_array($want, STATUSES, true) || $want === $rec['status']) flash('error', 'Pick a record and a different status.');
        elseif ($reason === '') flash('error', 'Please explain why the record is wrong.');
        else {
            $q = $pdo->prepare("SELECT COUNT(*) FROM correction_requests WHERE attendance_id=? AND status='PENDING'"); $q->execute([$aid]);
            if ($q->fetchColumn()) flash('error', 'There is already a pending request for that record.');
            else {
                $pdo->prepare('INSERT INTO correction_requests (attendance_id,student_id,requested_status,reason) VALUES (?,?,?,?)')->execute([$aid, $sid, $want, mb_substr($reason, 0, 500)]);
                audit($pdo, 'CORRECTION_REQUEST', 'correction_requests', $pdo->lastInsertId(), $rec['status'] . ' -> ' . $want);
                flash('ok', 'Correction request sent to the teacher.');
            }
        }
        redirect('student.php?tab=corrections');
    }
    if ($form === 'profile') {
        $email = trim($_POST['email'] ?? ''); $phone = trim($_POST['phone'] ?? '');
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) flash('error', 'That email address is not valid.');
        elseif ($phone !== '' && !preg_match('/^[0-9+\- ]{7,20}$/', $phone)) flash('error', 'That phone number is not valid.');
        else { $pdo->prepare('UPDATE students SET email=?, phone=? WHERE student_id=?')->execute([$email ?: null, $phone ?: null, $sid]); flash('ok', 'Profile updated.'); }
        redirect('student.php?tab=profile');
    }
    if ($form === 'password') {
        $q = $pdo->prepare('SELECT password_hash FROM users WHERE user_id=?'); $q->execute([$_SESSION['user_id']]); $hash = $q->fetchColumn();
        $new = $_POST['new_password'] ?? '';
        if (!password_verify($_POST['old_password'] ?? '', $hash)) flash('error', 'Current password is wrong.');
        elseif (strlen($new) < 8 || $new !== ($_POST['confirm_password'] ?? '')) flash('error', 'New password must be at least 8 characters and match the confirmation.');
        else { $pdo->prepare('UPDATE users SET password_hash=? WHERE user_id=?')->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['user_id']]); audit($pdo, 'PASSWORD_CHANGE', 'users', $_SESSION['user_id']); flash('ok', 'Password changed.'); }
        redirect('student.php?tab=profile');
    }
}

page_header('Student Dashboard');
echo '<h1>Student Dashboard</h1><p class="muted">' . h($st['full_name']) . ' · Roll No: ' . h($st['roll_no']) . '</p>';

// ---------- TAB: home ----------
if ($tab === 'home') {
    $rows = student_summary($pdo, $sid);
    echo '<section class="card"><h2>Subject-wise attendance</h2><div class="table-wrap"><table><thead><tr><th>Subject</th><th>Classes held</th><th>Present</th><th>Absent</th><th>Leave</th><th>Attendance %</th><th>Status</th></tr></thead><tbody>';
    foreach ($rows as $r) {
        $pct = $r['pct'];
        $status = $pct === null ? 'No sessions yet' : ($pct < $limit ? 'Below ' . $limit . '%' : 'At / above ' . $limit . '%');
        $cls = $pct !== null && $pct < $limit ? ' class="below"' : '';
        echo '<tr' . $cls . '><td>' . h($r['subject_name']) . '</td><td>' . (int)$r['held'] . '</td><td>' . (int)$r['present_n'] . '</td><td>' . (int)$r['absent_n'] . '</td><td>' . (int)$r['leave_n'] . '</td><td>' . ($pct === null ? '—' : number_format($pct, 2) . '%') . '</td><td>' . h($status) . '</td></tr>';
    }
    if (!$rows) echo '<tr><td colspan="7" class="muted">You are not enrolled in any subject yet.</td></tr>';
    echo '</tbody></table></div><p class="muted small">Attendance = (present' . (setting($pdo, 'leave_counts_as_present', '1') === '1' ? ' + approved leave' : '') . ') ÷ classes held × 100. The shortage threshold is ' . h($limit) . '%.</p></section>';
}

// ---------- TAB: daily (list + calendar) ----------
if ($tab === 'daily') {
    $month = $_GET['month'] ?? date('Y-m'); if (!preg_match('/^\d{4}-\d{2}$/', $month)) $month = date('Y-m');
    $first = $month . '-01'; $last = date('Y-m-t', strtotime($first));
    $q = $pdo->prepare("SELECT ses.session_date, sub.subject_name, a.status FROM attendance a JOIN sessions ses ON ses.session_id=a.session_id JOIN subjects sub ON sub.subject_id=ses.subject_id WHERE a.student_id=? AND ses.status='CLOSED' AND ses.session_date BETWEEN ? AND ? ORDER BY ses.session_date, sub.subject_name");
    $q->execute([$sid, $first, $last]); $recs = $q->fetchAll(); $byDay = [];
    foreach ($recs as $r) $byDay[$r['session_date']][] = $r;
    $prev = date('Y-m', strtotime($first . ' -1 month')); $next = date('Y-m', strtotime($first . ' +1 month'));
    echo '<section class="card"><h2>' . h(date('F Y', strtotime($first))) . '</h2><p><a href="?tab=daily&month=' . $prev . '">← Previous</a> · <a href="?tab=daily&month=' . $next . '">Next →</a></p><div class="cal">';
    foreach (['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as $d) echo '<div class="calh">' . $d . '</div>';
    for ($i = 1; $i < (int)date('N', strtotime($first)); $i++) echo '<div class="calc empty"></div>';
    for ($d = 1; $d <= (int)date('t', strtotime($first)); $d++) {
        $date = sprintf('%s-%02d', $month, $d); $items = $byDay[$date] ?? []; $cls = '';
        if ($items) { $all = array_column($items, 'status'); $cls = in_array('ABSENT', $all) ? 'bad' : (in_array('LEAVE', $all) ? 'warn' : 'ok'); }
        echo '<div class="calc ' . $cls . '"><b>' . $d . '</b>';
        foreach ($items as $it) echo '<small>' . h(mb_substr($it['subject_name'], 0, 14)) . ': ' . h(substr($it['status'], 0, 1)) . '</small>';
        echo '</div>';
    }
    echo '</div><p class="muted small">Green = all present · Yellow = leave · Red = absent in at least one class. P / A / L inside each box.</p></section>';
    echo '<section class="card"><h2>Day-by-day list</h2><div class="table-wrap"><table><thead><tr><th>Date</th><th>Subject</th><th>Status</th></tr></thead><tbody>';
    foreach (array_reverse($recs) as $r) echo '<tr><td>' . h($r['session_date']) . '</td><td>' . h($r['subject_name']) . '</td><td>' . status_badge($r['status']) . '</td></tr>';
    if (!$recs) echo '<tr><td colspan="3" class="muted">No attendance recorded this month.</td></tr>';
    echo '</tbody></table></div></section>';
}

// ---------- TAB: leave ----------
if ($tab === 'leave') {
    echo '<section class="card"><h2>Apply for leave</h2><form method="post"><input type="hidden" name="form" value="leave">' . csrf_field() . '<div class="form-grid"><div><label>From</label><input type="date" name="from_date" required></div><div><label>To</label><input type="date" name="to_date" required></div></div><label>Reason</label><input name="reason" required maxlength="500"><button>Submit request</button></form></section>';
    $q = $pdo->prepare('SELECT * FROM leave_requests WHERE student_id=? ORDER BY created_at DESC, leave_id DESC'); $q->execute([$sid]);
    echo '<section class="card"><h2>My leave requests</h2><div class="table-wrap"><table><thead><tr><th>Dates</th><th>Reason</th><th>Status</th><th>Note</th><th></th></tr></thead><tbody>';
    foreach ($q->fetchAll() as $l) {
        echo '<tr><td>' . h($l['from_date']) . ' → ' . h($l['to_date']) . '</td><td>' . h($l['reason']) . '</td><td>' . status_badge($l['status']) . '</td><td>' . h($l['decision_note']) . '</td><td>';
        if ($l['status'] === 'PENDING') echo '<form method="post"><input type="hidden" name="form" value="cancel_leave"><input type="hidden" name="leave_id" value="' . (int)$l['leave_id'] . '">' . csrf_field() . '<button class="secondary small">Cancel</button></form>';
        echo '</td></tr>';
    }
    echo '</tbody></table></div></section>';
}

// ---------- TAB: corrections ----------
if ($tab === 'corrections') {
    $days = (int)setting($pdo, 'edit_window_days', 7) + 7;
    $q = $pdo->prepare("SELECT a.attendance_id, a.status, ses.session_date, sub.subject_name FROM attendance a JOIN sessions ses ON ses.session_id=a.session_id JOIN subjects sub ON sub.subject_id=ses.subject_id WHERE a.student_id=? AND ses.session_date>=? ORDER BY ses.session_date DESC");
    $q->execute([$sid, date('Y-m-d', strtotime("-$days days"))]); $recent = $q->fetchAll();
    echo '<section class="card"><h2>Request a correction</h2><p class="muted">Think a record is wrong? Pick it, say what it should be, and explain. The subject teacher will review it.</p><form method="post"><input type="hidden" name="form" value="correction">' . csrf_field() . '<label>Record</label><select name="attendance_id" required><option value="">Choose a record</option>';
    foreach ($recent as $r) echo '<option value="' . (int)$r['attendance_id'] . '">' . h($r['session_date'] . ' — ' . $r['subject_name'] . ' (currently ' . $r['status'] . ')') . '</option>';
    echo '</select><label>It should be</label>' . status_select('requested_status', 'PRESENT') . '<label>Reason</label><input name="reason" required maxlength="500"><button>Send request</button></form></section>';
    $q = $pdo->prepare('SELECT cr.*, ses.session_date, sub.subject_name FROM correction_requests cr JOIN attendance a ON a.attendance_id=cr.attendance_id JOIN sessions ses ON ses.session_id=a.session_id JOIN subjects sub ON sub.subject_id=ses.subject_id WHERE cr.student_id=? ORDER BY cr.created_at DESC, cr.correction_id DESC'); $q->execute([$sid]);
    echo '<section class="card"><h2>My requests</h2><div class="table-wrap"><table><thead><tr><th>Date</th><th>Subject</th><th>Wanted</th><th>Reason</th><th>Status</th><th>Teacher note</th></tr></thead><tbody>';
    foreach ($q->fetchAll() as $c) echo '<tr><td>' . h($c['session_date']) . '</td><td>' . h($c['subject_name']) . '</td><td>' . status_badge($c['requested_status']) . '</td><td>' . h($c['reason']) . '</td><td>' . status_badge($c['status']) . '</td><td>' . h($c['decision_note']) . '</td></tr>';
    echo '</tbody></table></div></section>';
}

// ---------- TAB: profile ----------
if ($tab === 'profile') {
    $q = $pdo->prepare('SELECT class_name,section,academic_year FROM classes WHERE class_id=?'); $q->execute([$st['class_id']]); $cl = $q->fetch();
    echo '<section class="card"><h2>Profile</h2><p><strong>Name:</strong> ' . h($st['full_name']) . '<br><strong>Roll no.:</strong> ' . h($st['roll_no']) . '<br><strong>Class:</strong> ' . h($cl ? class_label($cl) . ' (' . $cl['academic_year'] . ')' : '-') . '</p><form method="post"><input type="hidden" name="form" value="profile">' . csrf_field() . '<div class="form-grid"><div><label>Email</label><input type="email" name="email" value="' . h($st['email']) . '" maxlength="120"></div><div><label>Phone</label><input name="phone" value="' . h($st['phone']) . '" maxlength="20"></div></div><button>Save profile</button></form></section>';
    echo '<section class="card"><h2>Change password</h2><form method="post"><input type="hidden" name="form" value="password">' . csrf_field() . '<label>Current password</label><input type="password" name="old_password" required><label>New password (min 8 characters)</label><input type="password" name="new_password" required minlength="8"><label>Confirm new password</label><input type="password" name="confirm_password" required><button>Change password</button></form></section>';
}
page_footer();
