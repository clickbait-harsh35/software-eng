<?php
require_once __DIR__ . '/../includes/lib.php';
require_role(['ADMIN', 'TEACHER']);
$isAdmin = $_SESSION['role'] === 'ADMIN';
$limit = threshold($pdo);

// What can this user pick?
if ($isAdmin) {
    $options = [];
    foreach (all_classes($pdo) as $c) foreach (all_subjects($pdo) as $s) {
        $q = $pdo->prepare('SELECT COUNT(*) FROM enrollments e JOIN students st ON st.student_id=e.student_id WHERE e.subject_id=? AND st.class_id=?'); $q->execute([$s['subject_id'], $c['class_id']]);
        if ($q->fetchColumn()) $options[] = ['class_id' => $c['class_id'], 'subject_id' => $s['subject_id'], 'label' => class_label($c) . ' — ' . $s['subject_name']];
    }
} else {
    $t = current_teacher($pdo); $options = [];
    foreach (teacher_allocations($pdo, $t['teacher_id']) as $a) $options[] = ['class_id' => $a['class_id'], 'subject_id' => $a['subject_id'], 'label' => class_label($a) . ' — ' . $a['subject_name']];
}

$sel = $_GET['alloc'] ?? ''; $from = $_GET['from'] ?? date('Y-m-01'); $to = $_GET['to'] ?? date('Y-m-d');
$mode = ($_GET['mode'] ?? 'class') === 'defaulters' ? 'defaulters' : 'class';
$rows = null; $label = '';
if ($sel !== '' && valid_date($from) && valid_date($to)) {
    [$cid, $sub] = array_map('intval', explode('|', $sel) + [0, 0]);
    foreach ($options as $o) if ((int)$o['class_id'] === $cid && (int)$o['subject_id'] === $sub) $label = $o['label'];
    if ($label !== '') {
        $rows = class_report($pdo, $cid, $sub, $from, $to);
        if ($mode === 'defaulters') $rows = array_values(array_filter($rows, fn($r) => $r['pct'] !== null && $r['pct'] < $limit));
        if (isset($_GET['csv'])) {
            audit($pdo, 'REPORT_EXPORT', 'report', "$cid|$sub", "$from to $to ($mode)");
            csv_download('attendance_' . $mode . '_' . $from . '_' . $to . '.csv', ['Roll no', 'Student', 'Classes held', 'Present', 'Absent', 'Leave', 'Attendance %', 'Below ' . $limit . '%'],
                array_map(fn($r) => [$r['roll_no'], $r['full_name'], $r['held'], $r['present_n'], $r['absent_n'], $r['leave_n'], $r['pct'] === null ? '' : $r['pct'], ($r['pct'] !== null && $r['pct'] < $limit) ? 'YES' : 'no'], $rows));
        }
    }
}

page_header('Reports');
echo '<h1>Attendance reports</h1><section class="card noprint"><form method="get"><div class="form-grid"><div><label>Class / Subject</label><select name="alloc" required><option value="">Select</option>';
foreach ($options as $o) { $v = $o['class_id'] . '|' . $o['subject_id']; echo '<option value="' . h($v) . '"' . ($v === $sel ? ' selected' : '') . '>' . h($o['label']) . '</option>'; }
echo '</select></div><div><label>Report type</label><select name="mode"><option value="class"' . ($mode === 'class' ? ' selected' : '') . '>Full class report</option><option value="defaulters"' . ($mode === 'defaulters' ? ' selected' : '') . '>Defaulters only (below ' . h($limit) . '%)</option></select></div><div><label>From</label><input type="date" name="from" value="' . h($from) . '"></div><div><label>To</label><input type="date" name="to" value="' . h($to) . '"></div></div><button>Show report</button></form></section>';
if ($rows !== null) {
    $qs = http_build_query(['alloc' => $sel, 'from' => $from, 'to' => $to, 'mode' => $mode, 'csv' => 1]);
    echo '<section class="card"><h2>' . h($label) . ' · ' . h($from) . ' to ' . h($to) . ($mode === 'defaulters' ? ' · Defaulters' : '') . '</h2><p class="noprint"><a href="reports.php?' . h($qs) . '">Download Excel/CSV</a> · <a href="#" onclick="window.print();return false">Print / save as PDF</a></p><div class="table-wrap"><table><thead><tr><th>Roll No.</th><th>Student</th><th>Held</th><th>Present</th><th>Absent</th><th>Leave</th><th>%</th></tr></thead><tbody>';
    foreach ($rows as $r) echo '<tr' . (($r['pct'] !== null && $r['pct'] < $limit) ? ' class="below"' : '') . '><td>' . h($r['roll_no']) . '</td><td>' . h($r['full_name']) . '</td><td>' . (int)$r['held'] . '</td><td>' . (int)$r['present_n'] . '</td><td>' . (int)$r['absent_n'] . '</td><td>' . (int)$r['leave_n'] . '</td><td>' . ($r['pct'] === null ? '—' : number_format($r['pct'], 2) . '%') . '</td></tr>';
    if (!$rows) echo '<tr><td colspan="7" class="muted">' . ($mode === 'defaulters' ? 'No defaulters in this period.' : 'No students found.') . '</td></tr>';
    echo '</tbody></table></div></section>';
}
page_footer();
