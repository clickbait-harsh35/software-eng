-- Run this ONLY if you already imported the old schema.sql and have data you want to keep.
-- (phpMyAdmin -> select attendance_db -> Import). If you are starting fresh, import schema.sql instead.
USE attendance_db;

ALTER TABLE attendance MODIFY status ENUM('PRESENT','ABSENT','LEAVE') NOT NULL;
ALTER TABLE sessions ADD UNIQUE KEY uq_session_day (class_id, subject_id, session_date);
ALTER TABLE students ADD COLUMN email VARCHAR(120) DEFAULT NULL, ADD COLUMN phone VARCHAR(30) DEFAULT NULL;

CREATE TABLE IF NOT EXISTS leave_requests (
  leave_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  from_date DATE NOT NULL,
  to_date DATE NOT NULL,
  reason TEXT NOT NULL,
  status ENUM('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  decided_by INT DEFAULT NULL,
  decided_at DATETIME DEFAULT NULL,
  decision_note TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(student_id),
  FOREIGN KEY (decided_by) REFERENCES users(user_id)
);
CREATE TABLE IF NOT EXISTS correction_requests (
  correction_id INT AUTO_INCREMENT PRIMARY KEY,
  attendance_id BIGINT NOT NULL,
  student_id INT NOT NULL,
  requested_status ENUM('PRESENT','ABSENT','LEAVE') NOT NULL,
  reason TEXT NOT NULL,
  status ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  decided_by INT DEFAULT NULL,
  decided_at DATETIME DEFAULT NULL,
  decision_note TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (attendance_id) REFERENCES attendance(attendance_id),
  FOREIGN KEY (student_id) REFERENCES students(student_id),
  FOREIGN KEY (decided_by) REFERENCES users(user_id)
);
CREATE TABLE IF NOT EXISTS settings (
  setting_key VARCHAR(60) PRIMARY KEY,
  setting_value VARCHAR(255) NOT NULL
);
INSERT IGNORE INTO settings (setting_key, setting_value) VALUES
  ('threshold', '75'),
  ('leave_counts_as_present', '1'),
  ('edit_window_days', '7');

-- If the ALTER TABLE ... ADD UNIQUE line fails with "Duplicate entry", you saved the same date twice
-- (the old bug). Delete the extra session rows (and their attendance rows) and run that line again.
