# Student Attendance Management System (version 2)

Local PHP + MySQL project. Roles: ADMIN, TEACHER, STUDENT.

## What is implemented
- Login with hashed passwords, sessions, CSRF tokens, prepared statements, 30-minute idle logout
- Teacher: mark attendance (Present / Absent / Leave, default Present), duplicate-date protection, edit past records with a required reason (audit logged), approve or reject leave and correction requests, class and defaulter reports
- Student: subject-wise percentage with shortage flag, month calendar and day-by-day list, apply for leave, request attendance corrections, profile and password change
- Admin: users (create, activate/deactivate, reset password), classes, subjects, teacher allocations, enrolments, leave decisions, edit any attendance record, settings (75% threshold, edit window, whether leave counts as attended), audit log, reports
- Reports: on screen, CSV (opens in Excel), and Print -> Save as PDF

## Not implemented
Registration with OTP, forgot-password OTP, e-mail/SMS notifications, QR attendance, database backup screen, login lockout, CAPTCHA.

## Run on Windows with XAMPP
1. Start Apache and MySQL in XAMPP.
2. Copy the `student-attendance` folder into `C:\xampp\htdocs\`.
3. phpMyAdmin -> Import -> `database/schema.sql` (fresh install).
   Already have the old database with data? Import `database/migration_v2.sql` instead.
4. Open `http://localhost/student-attendance/setup.php` once (creates demo data), then delete `setup.php`.
5. Open `http://localhost/student-attendance/public/`.

## Demo accounts
| Role | Username | Password |
|---|---|---|
| Administrator | `admin` | `Admin@123` |
| Teacher | `teacher1` | `Teacher@123` |
| Student | `student1` | `Student@123` |
| Student | `student2` | `Student@123` |

## Database settings
`config/config.php` (default XAMPP: user `root`, blank password).

## Important
Academic prototype. Use fictional data, change the demo passwords, and delete `setup.php` after setup.
